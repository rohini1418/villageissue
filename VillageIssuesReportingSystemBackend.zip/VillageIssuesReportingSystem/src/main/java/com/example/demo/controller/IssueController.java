package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Issue;
import com.example.demo.model.User;
import com.example.demo.service.IssueService;
import com.example.demo.service.UserService;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/issues")
public class IssueController {

    private IssueService issueService;
    private UserService userService;

    @Autowired
    public IssueController(IssueService issueService, UserService userService) {
        this.issueService = issueService;
        this.userService = userService;
    }

    // ---------------------------------------------------------
    // GET ISSUE BY ID (EDIT PAGE LOAD)
    // ---------------------------------------------------------
    @GetMapping("getIssues/{issueId}")
    public ResponseEntity<Issue> getIssueByIssueId(@PathVariable("issueId") int issueId) {
        return new ResponseEntity<>(issueService.getIssueById(issueId), HttpStatus.OK);
    }

    // ---------------------------------------------------------
    // ADD ISSUE
    // ---------------------------------------------------------
    @PostMapping(value = "/add", consumes = {"multipart/form-data"})
    public ResponseEntity<Issue> addIssue(
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("villageName") String villageName,
            @RequestParam("category") String category,
            @RequestParam("status") String status,
            @RequestParam("createdDate") String createdDate,
            @RequestParam("userId") Long userId,
            @RequestParam(value = "photo", required = false) MultipartFile photo
    ) {

        Optional<User> userOpt = userService.getUserById(userId);
        if (!userOpt.isPresent()) {
            return ResponseEntity.badRequest().build();
        }

        Issue issue = new Issue();
        issue.setTitle(title);
        issue.setDescription(description);
        issue.setVillageName(villageName);
        issue.setCategory(category);
        issue.setStatus(status);
        issue.setCreatedDate(LocalDate.parse(createdDate));
        issue.setUser(userOpt.get());

        if (photo != null && !photo.isEmpty()) {
            try {
                issue.setPhoto(photo.getBytes());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Issue savedIssue = issueService.addIssue(issue);
        return ResponseEntity.ok(savedIssue);
    }

    // ---------------------------------------------------------
    // UPDATE ISSUE (EDIT PAGE SAVE) ✅ FIXED
    // ---------------------------------------------------------
    @PutMapping("/update/{id}")
    public ResponseEntity<Issue> updateIssue(@PathVariable int id, @RequestBody Issue issue) {

        Issue existingIssue = issueService.getIssueById(id);

        if (existingIssue == null) {
            return ResponseEntity.notFound().build();
        }

        // ONLY editable fields
        existingIssue.setTitle(issue.getTitle());
        existingIssue.setDescription(issue.getDescription());
        existingIssue.setVillageName(issue.getVillageName());
        existingIssue.setCategory(issue.getCategory());
        existingIssue.setCreatedDate(issue.getCreatedDate());

        Issue savedIssue = issueService.addIssue(existingIssue);
        return ResponseEntity.ok(savedIssue);
    }

    // ---------------------------------------------------------
    // UPDATE ONLY RESPONSE
    // ---------------------------------------------------------
    @PutMapping("/update-response/{id}")
    public ResponseEntity<Issue> updateIssueResponse(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        String response = body.get("response");
        if (response == null) {
            return ResponseEntity.badRequest().build();
        }

        Issue updated = issueService.updateResponse(id, response);
        return ResponseEntity.ok(updated);
    }

    // ---------------------------------------------------------
    // UPDATE ONLY STATUS
    // ---------------------------------------------------------
    @PutMapping("/status/{id}")
    public ResponseEntity<Issue> updateStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        String status = body.get("status");
        if (status == null) {
            return ResponseEntity.badRequest().build();
        }

        Issue updated = issueService.updateStatus(id, status);
        return ResponseEntity.ok(updated);
    }

    // ---------------------------------------------------------
    // GET ALL ISSUES
    // ---------------------------------------------------------
    @GetMapping("/all")
    public ResponseEntity<List<Issue>> getAllIssues() {
        return ResponseEntity.ok(issueService.getAllIssues());
    }

    // ---------------------------------------------------------
    // GET ISSUES BY USER
    // ---------------------------------------------------------
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Issue>> getIssuesByUser(@PathVariable Long userId) {

        Optional<User> userOpt = userService.getUserById(userId);
        return userOpt.map(user ->
                ResponseEntity.ok(issueService.getIssuesByUser(user))
        ).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ---------------------------------------------------------
    // DELETE ISSUE
    // ---------------------------------------------------------
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteIssue(@PathVariable Long id) {
        issueService.deleteIssue(id);
        return ResponseEntity.ok().build();
    }

    // ---------------------------------------------------------
    // NOTIFY USER
    // ---------------------------------------------------------
    @PostMapping("/notify")
    public ResponseEntity<String> notifyUser(@RequestBody Map<String, Object> body) {

        try {
            Long issueId = Long.valueOf(String.valueOf(body.get("issueId")));

            issueService.updateResponse(issueId, "Notification sent to user");
            return ResponseEntity.ok("Notification sent successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500)
                    .body("Error sending notification: " + e.getMessage());
        }
    }
}
