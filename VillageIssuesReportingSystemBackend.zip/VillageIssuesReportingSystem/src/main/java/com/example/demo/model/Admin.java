package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "admins")
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "admin_id")
    private Integer adminId;

    @NotBlank(message = "Name cannot be blank")
    @Size(max = 50, message = "Name must not exceed 50 characters")
    @Column(length = 50, nullable = false)
    private String name;

    @NotBlank(message = "Username cannot be blank")
    @Size(max = 30, message = "Username must not exceed 30 characters")
    @Column(length = 30, nullable = false, unique = true)
    private String username;

    @NotBlank(message = "Password cannot be blank")
    @Size(max = 20, message = "Password must not exceed 20 characters")
    @Column(length = 20, nullable = false)
    private String password;

    // Constructors
    public Admin() {}

    public Admin(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;
    }

    // Getters and Setters
    public Integer getAdminId() { return adminId; }
    public void setAdminId(Integer adminId) { this.adminId = adminId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
