package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.util.Base64;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
@Table(name = "issues")
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "issue_id")
    private Integer issueId;

    @NotBlank(message = "Title is required")
    @Size(min = 5, max = 100, message = "Title must be 5 to 100 characters")
    @Column(length = 100, nullable = false)
    private String title;

    @NotBlank(message = "Description is required")
    @Size(min = 10, max = 500, message = "Description must be 10 to 500 characters")
    @Column(length = 500, nullable = false)
    private String description;

    @NotBlank(message = "Village name is required")
    @Column(length = 100, nullable = false)
    private String villageName;

    @NotBlank(message = "Category is required")
    @Column(length = 50, nullable = false)
    private String category;

    @NotBlank(message = "Status is required")
    @Column(length = 20, nullable = false)
    private String status;     // PENDING, IN_PROGRESS, RESOLVED

    // ✅ IMAGE STORED IN DATABASE
    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] photo;

    @Column(length = 500)
    private String response; 
    
    @NotNull(message = "Date is required")
    @Column(nullable = false)
    private LocalDate createdDate;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // ✅ CONSTRUCTOR
    public Issue() {
    }

    // ✅ ADD THIS ONLY - for frontend image display
    @Transient
    public String getPhotoBase64() {
        if (this.photo != null) {
            return Base64.getEncoder().encodeToString(this.photo);
        }
        return null;
    }

    // ✅ GETTERS & SETTERS

    public Integer getIssueId() {
        return issueId;
    }

    public void setIssueId(Integer issueId) {
        this.issueId = issueId;
    }

    public String getTitle() {
        return title;
    }
  
    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }
  
    public void setDescription(String description) {
        this.description = description;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getCategory() {
        return category;
    }
  
    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }
  
    public void setStatus(String status) {
        this.status = status;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }
    
    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }
  
    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    public User getUser() {
        return user;
    }
  
    public void setUser(User user) {
        this.user = user;
    }
}
