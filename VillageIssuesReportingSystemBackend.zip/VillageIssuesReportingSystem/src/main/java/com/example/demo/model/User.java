package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;   

    // NAME VALIDATION
    @NotBlank(message = "Name cannot be blank")
    @Size(max = 32, message = "Name must not exceed 32 characters")
    @Pattern(
        regexp = "^[A-Z][A-Za-z ]{2,31}$",
        message = "Name must start with a capital letter, be 3–32 chars, and must not contain dots"
    )
    @Column(nullable = false, unique = true, length = 32)
    private String name;

    // PHONE VALIDATION
    @NotBlank(message = "Phone number cannot be blank")
    @Size(min = 10, max = 10, message = "Phone must be exactly 10 digits")
    @Pattern(
        regexp = "^[6-9][0-9]{9}$",
        message = "Phone must be a valid 10-digit Indian number starting with 6/7/8/9"
    )
    @Column(nullable = false, unique = true, length = 10)
    private String phone;

    // EMAIL VALIDATION
    @NotBlank(message = "Email cannot be blank")
    @Size(max = 50, message = "Email must not exceed 50 characters")
    @Pattern(
        regexp = "^[A-Za-z0-9._%+-]+@gmail\\.com$",
        message = "Email must be a valid Gmail address (example@gmail.com)"
    )
    @Column(nullable = false, unique = true, length = 50)
    private String email;

    // PASSWORD VALIDATION
    @NotBlank(message = "Password cannot be blank")
    @Size(max = 9, message = "Password must be max 9 characters")
    @Pattern(
        regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{1,9}$",
        message = "Password must be max 9 chars, include uppercase, lowercase, number and special symbol"
    )
    @Column(nullable = false, unique = true, length = 9)
    private String password;

    // ROLE VALIDATION
    @NotBlank(message = "Role is required")
    @Size(max = 10, message = "Role must not exceed 10 characters")
    @Pattern(
        regexp = "USER|ADMIN",
        message = "Role must be USER or ADMIN"
    )
    @Column(nullable = false, length = 10)
    private String role;

    public User() {}

    public User(String name, String phone, String email, String password, String role) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    // GETTERS AND SETTERS
    public Integer getUserId() { return userId; }  // FIXED
    public void setUserId(Integer userId) { this.userId = userId; }  // FIXED

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
