package com.example.demo.service;

import com.example.demo.model.Issue;
import com.example.demo.model.Admin;

import java.util.List;
import java.util.Optional;

public interface AdminService {

    // Issue operations
    List<Issue> getPendingIssues();
    Optional<Issue> updateIssueStatus(Long issueId, String status);

    // Admin operations
    Admin saveAdmin(Admin admin);
    Optional<Admin> getAdminById(Long id);
    List<Admin> getAllAdmins();
    void deleteAdmin(Long id);
}
