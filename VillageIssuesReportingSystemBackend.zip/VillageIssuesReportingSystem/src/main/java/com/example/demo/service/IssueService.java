package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import com.example.demo.model.Issue;
import com.example.demo.model.User;

public interface IssueService {
    Issue addIssue(Issue issue);
    List<Issue> getAllIssues();
    List<Issue> getIssuesByUser(User user);
    Optional<Issue> updateIssue(int issueId, Issue issue);
    void deleteIssue(Long issueId);
    Issue getIssueById(int id);
    Issue updateResponse(Long id, String response);
    Issue updateStatus(Long id,String status);

}
