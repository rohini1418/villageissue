package com.example.demo.serviceImpl;

import com.example.demo.model.Issue;
import com.example.demo.model.Admin;
import com.example.demo.repository.IssueRepository;
import com.example.demo.repository.AdminRepository;
import com.example.demo.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    private final IssueRepository issueRepository;
    private final AdminRepository adminRepository;

    @Autowired
    public AdminServiceImpl(IssueRepository issueRepository, AdminRepository adminRepository) {
        this.issueRepository = issueRepository;
        this.adminRepository = adminRepository;
    }

    // Issue methods
    @Override
    public List<Issue> getPendingIssues() {
        return issueRepository.findByStatus("PENDING");
    }

    @Override
    public Optional<Issue> updateIssueStatus(Long issueId, String status) {
        Optional<Issue> issueOpt = issueRepository.findById(issueId);
        issueOpt.ifPresent(issue -> {
            issue.setStatus(status);
            issueRepository.save(issue);
        });
        return issueOpt;
    }

    // Admin methods
    @Override
    public Admin saveAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    @Override
    public Optional<Admin> getAdminById(Long id) {
        return adminRepository.findById(id);
    }

    @Override
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    @Override
    public void deleteAdmin(Long id) {
        adminRepository.deleteById(id);
    }
}
