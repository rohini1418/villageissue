package com.example.demo.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Issue;
import com.example.demo.model.User;
import com.example.demo.repository.IssueRepository;
import com.example.demo.service.IssueService;

import java.util.List;
import java.util.Optional;

@Service
public class IssueServiceImpl implements IssueService {

    private final IssueRepository issueRepository;

    @Autowired
    public IssueServiceImpl(IssueRepository issueRepository) {
        this.issueRepository = issueRepository;
    }

    @Override
    public Issue addIssue(Issue issue) {
        return issueRepository.save(issue);
    }

    @Override
    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    @Override
    public List<Issue> getIssuesByUser(User user) {
        return issueRepository.findByUser(user);
    }

    @Override
    public Optional<Issue> updateIssue(int issueId, Issue issueDetails) {
        Optional<Issue> issueOpt = issueRepository.findById((long) issueId);
        if (issueOpt.isPresent()) {
            Issue issue = issueOpt.get();
            issue.setTitle(issueDetails.getTitle());
            issue.setDescription(issueDetails.getDescription());
            issue.setCategory(issueDetails.getCategory());
            issue.setVillageName(issueDetails.getVillageName());
            issue.setStatus(issueDetails.getStatus());
            issue.setPhoto(issueDetails.getPhoto());
            issue.setResponse(issueDetails.getResponse());
            issue.setStatus(issueDetails.getStatus());
            issueRepository.save(issue);
        }
        return issueOpt;
    }

    @Override
    public void deleteIssue(Long issueId) {
        issueRepository.deleteById(issueId);
    }

    // ⭐⭐⭐ ADDED METHOD 1 — get by ID
    @Override
    public Issue getIssueById(int id) {
        return issueRepository.findById((long) id)
                .orElseThrow(() -> new RuntimeException("Issue not found"));
    }

    // ⭐⭐⭐ ADDED METHOD 2 — update response
    
    
    @Override
    public Issue updateResponse(Long id, String response) {
        Issue issue = issueRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Issue not found"));

        issue.setResponse(response);
        return issueRepository.save(issue);
    }
    
    public Issue updateStatus(Long issueId, String status) {
        Issue issue = issueRepository.findById(issueId)
            .orElseThrow(() -> new RuntimeException("Issue not found: " + issueId));

        issue.setStatus(status);
        return issueRepository.save(issue);
    }

    	
    }
    
    

