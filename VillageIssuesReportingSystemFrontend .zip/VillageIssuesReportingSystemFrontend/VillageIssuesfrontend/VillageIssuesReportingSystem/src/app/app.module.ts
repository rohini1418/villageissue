import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing-module';

import { App } from './app';
import { Register } from './components/register/register';
import { Login } from './components/login/login';
import { Dashboard } from './components/dashboard/dashboard';
import { ReportIssue } from './components/report-issue/report-issue';
import { Admin } from './components/admin/admin';
import { Viewissues } from './components/viewissues/viewissues';
import { NotifyIssue } from './components/notifyuser/notifyuser';
import { NavBarComponent } from './nav-bar/nav-bar';


@NgModule({
  declarations: [
    App,
    ReportIssue,
    NotifyIssue,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,    
    RouterModule, 
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule { }
