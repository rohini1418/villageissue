import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent} from './components/home/home';
import { Register } from './components/register/register';
import { Login } from './components/login/login';
import { Dashboard } from './components/dashboard/dashboard';
import { ReportIssue } from './components/report-issue/report-issue'; 
import { Admin } from './components/admin/admin';
import { Viewissues } from './components/viewissues/viewissues';
import { NotifyIssue } from './components/notifyuser/notifyuser';

import { ForgotPasswordComponent } from './components/forgot-password/forgot-password';
import { ResetPasswordComponent } from './components/reset-password/reset-password';




const routes: Routes = [
  { path: '', component:HomeComponent},
  { path: 'register', component: Register },
  { path: 'login', component: Login },
   { path: 'dashboard/:id', component: Dashboard },
   { path: 'report-issue/:id', component: ReportIssue },
   { path: 'admin',component:Admin},
   {path: 'viewissues',component:Viewissues},
  { path: 'notify/:issueId', component: NotifyIssue },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'register', loadComponent: () => import('./components/register/register').then(m => m.Register) },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'reset-password/:email', component: ResetPasswordComponent }

   


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
