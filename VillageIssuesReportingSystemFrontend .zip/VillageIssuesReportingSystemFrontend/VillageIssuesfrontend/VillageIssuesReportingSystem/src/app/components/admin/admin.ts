import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-admin',
  standalone:true,
  templateUrl: './admin.html',
  styleUrls: ['./admin.css']
})
export class Admin {

  constructor(private authservice: Auth, private router: Router) {}

  viewIssues() {
    this.router.navigate(['/viewissues']);
  }
}