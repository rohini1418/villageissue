import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NavBarComponent } from '../../nav-bar/nav-bar';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, NavBarComponent, RouterModule]
})
export class Dashboard implements OnInit {
  loading: boolean = true;
  userId!: number;
  issues: any[] = [];

  // Precomputed stats
  totalIssues: number = 0;
  pendingIssues: number = 0;
  inProgressIssues: number = 0;
  resolvedIssues: number = 0;

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router, private cd:ChangeDetectorRef) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.userId = +idParam;
      this.loadUserIssues();
    }
  }

  loadUserIssues() {
    this.http.get<any[]>(`http://localhost:8084/issues/user/${this.userId}`)
      .subscribe({
        next: (data) => {
          this.issues = data || [];
          this.cd.detectChanges();
          this.calculateStats();
          this.loading = false;
        },
        error: (err) => {
          console.error(err);
          this.loading = false;
        }
      });
  }

  calculateStats() {
    this.totalIssues = this.issues.length;
    this.pendingIssues = this.issues.filter(i => i.status === 'PENDING').length;
    this.inProgressIssues = this.issues.filter(i => i.status === 'IN_PROGRESS').length;
    this.resolvedIssues = this.issues.filter(i => i.status === 'RESOLVED').length;
  }

  goToReportIssue() {
    this.router.navigate(['/report-issue', this.userId]);
  }

  logout() {
    this.router.navigate(['/login']);
  }

  goToHome() {
    this.router.navigate(['/']);
  }
}
