import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './forgot-password.html',
  styleUrls: ['./forgot-password.css']
})
export class ForgotPasswordComponent {

  email: string = '';
  message: string = '';

  constructor(private router: Router) {}

  submitEmail() {
    if (!this.email) {
      this.message = 'Please enter your registered email';
      return;
    }

    // Example: Call backend API to send reset link
    console.log('Forgot password request for:', this.email);
    this.message = '';
    alert('Reset link sent to your email!');

    // Navigate to Reset Password page (with email as param)
    this.router.navigate(['/reset-password', this.email]);
  }
}
