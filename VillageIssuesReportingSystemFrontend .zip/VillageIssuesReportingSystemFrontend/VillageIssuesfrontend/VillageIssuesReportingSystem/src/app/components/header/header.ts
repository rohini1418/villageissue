import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-header',
  standalone:true,
  templateUrl: './header.html'
})
export class Header {

  constructor(
    public auth: Auth,
    private router: Router
  ) {}

  logout() {
    this.auth.logout();
    this.router.navigate(['/home']); // 👈 logout aada mele home ge hogutte
  }
}
