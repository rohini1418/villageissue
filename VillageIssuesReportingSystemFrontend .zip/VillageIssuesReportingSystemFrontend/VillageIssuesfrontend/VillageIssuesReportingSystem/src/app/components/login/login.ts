import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';
import { User } from '../../model/user';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {

  user = new User();
  message = '';
  userId: any;
  showPassword = false;

  constructor(private router: Router, private authService: Auth) {}

  onLogin() {
    if (!this.user.email || !this.user.password) {
      this.message = "Enter Email and Password";
      return;
    }

    this.authService.loginUser(this.user).subscribe(
      (userobj: any) => {
        console.log('Login response:', userobj);

        if (userobj && userobj.userId) {
          this.message = '';
          alert("User logged in successfully");

          localStorage.setItem('token', userobj.token);
          this.userId = userobj.userId;
          localStorage.setItem('user', JSON.stringify(userobj));
          localStorage.setItem('userId', userobj.userId);

          if (userobj.role?.toUpperCase() === "USER") {
            this.router.navigate(['/dashboard', this.userId]);
          }
          else if (userobj.role?.toUpperCase() === "ADMIN") {
            this.router.navigate(['/admin']);
          }
          else {
            alert("Invalid role");
          }
        } else {
          // User not registered or invalid credentials
          this.message = "Email or password is incorrect. Please register if you are new.";
        }
      },
      error => {
        console.error('Login error:', error);
        this.message = "Server error during login";
      }
    );
  }

  // Toggle password visibility
  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  forgotPassword() {
  this.router.navigate(['/forgot-password']);
}

}
