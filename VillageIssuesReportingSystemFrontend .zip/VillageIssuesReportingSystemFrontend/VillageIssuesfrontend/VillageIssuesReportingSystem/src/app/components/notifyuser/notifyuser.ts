import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-notification',
  standalone:false,
  templateUrl: './notifyuser.html',
styleUrls: ['./notifyuser.css'],

})
export class NotifyIssue implements OnInit {

  issue: any;
  issueId: number = 0;       // ✅ Add this
  response: string = '';

  constructor(private route: ActivatedRoute, private authservice: Auth,private router:Router, private cd:ChangeDetectorRef) {}

  ngOnInit() {

    const idParam = this.route.snapshot.paramMap.get('issueId');  
    this.issueId = Number(idParam);  
console.log(this.issueId);
    this.authservice.getSingleIssue(this.issueId)
      .subscribe((data: any) => {
        console.log(data);
        this.issue = data;
        this.cd.detectChanges();
      });
  }

 notifyUpdate() {
  //const body = { response: this.response };
  console.log("notify update");
  console.log(this.issue)
 this.authservice.updateIssueResponse(String(this.issueId), this.issue)
  .subscribe(res => {
    alert("issue updated");
    this.router.navigate(['viewissues']); // navigate first
    setTimeout(() => alert(res), 100); // show alert after navigation
  });

}

}
