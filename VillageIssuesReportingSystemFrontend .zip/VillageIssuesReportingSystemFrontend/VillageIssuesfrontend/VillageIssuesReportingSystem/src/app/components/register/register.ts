import { Component } from '@angular/core';
import { User } from '../../model/user';
import { Auth } from '../../services/auth';
import { Router } from '@angular/router'; // ✅ Use Router here
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone:true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {

  user: User = new User();
  message: string = '';
  showPassword: boolean = false; // toggle password

  constructor(private authservice: Auth, private router: Router) {} // ✅ inject Router

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  register() {
    console.log("Sending data:", this.user);

    if (!this.user.role) {
      this.user.role = "USER";  // default role
    }

    this.authservice.registerUsers(this.user).subscribe(
      res => {
        console.log("Response:", res);
        this.message = "Registration successful!";
        setTimeout(() => this.router.navigate(['/login']), 1500); // ✅ works now
      },
      err => {
        console.log("Error:", err);
        this.message = "Registration failed. Please try again.";
      }
    );
  }
}
