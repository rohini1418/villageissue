import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-report-issue',
  standalone:false,
  templateUrl: './report-issue.html',
  styleUrls: ['./report-issue.css']
})
export class ReportIssue {

  issueData = {
    title: '',
    description: '',
    villageName: '',
    category: '',
    status: 'PENDING',
    createdDate: '',
    user: {
      userId: 0
    }
  };

  selectedImage: File | null = null;

  constructor(private auth: Auth, private router: Router) {
    // set today date
    this.issueData.createdDate = new Date().toISOString().split('T')[0];

    // get userId from localStorage
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.issueData.user.userId = Number(userId);
    }
  }

  onFileSelect(event: any) {
    if (event.target.files.length > 0) {
      this.selectedImage = event.target.files[0];
    }
  }

  submitIssue() {
    const formData = new FormData();
    formData.append("title", this.issueData.title);
    formData.append("description", this.issueData.description);
    formData.append("villageName", this.issueData.villageName);
    formData.append("category", this.issueData.category);
    formData.append("status", this.issueData.status);
    formData.append("createdDate", this.issueData.createdDate);

    formData.append("userId", this.issueData.user.userId.toString());

    if (this.selectedImage) {
      formData.append("photo", this.selectedImage);
    }
    console.log("7777777777777777777777777777777777777777777777777");
console.log(formData);
    // ✅ Use Auth service for reporting issue
   this.auth.reportIssue(formData).subscribe({
      next: (res: any) => {   // or use HttpResponse<any>
    console.log('Server response:', res); // now value is used
    alert("Issue Reported Successfully!");

        const role = localStorage.getItem('role'); // admin or user
        if (role && role.toUpperCase() === 'ADMIN') {
          this.router.navigate(['/admin']); // admin page
        } else {
          this.router.navigate(['/user']); // user page
        }
      },
       error: (err: any) => {   // ✅ add ': any' here
    console.error("Server Error:", err);
    alert("Failed to report issue!");
  }
    });
  }
}
