import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './reset-password.html',
  styleUrls: ['./reset-password.css']
})
export class ResetPasswordComponent {

  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  showPassword: boolean = false;
  message: string = '';

  constructor(private router: Router, private route: ActivatedRoute) {
    this.email = this.route.snapshot.params['email'] || '';
  }

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  resetPassword() {
    if (!this.password || !this.confirmPassword) {
      this.message = 'Please enter all fields';
      return;
    }

    if (this.password !== this.confirmPassword) {
      this.message = 'Passwords do not match';
      return;
    }

    if (!this.validatePassword(this.password)) {
      this.message = 'Password must be 8+ chars, with uppercase, lowercase, number, and symbol';
      return;
    }

    // Call backend API to reset password
    console.log('Reset password for:', this.email, this.password);
    this.message = '';
    alert('Password reset successfully!');

    // Navigate back to login page
    this.router.navigate(['/login']);
  }

  validatePassword(password: string): boolean {
    const strongPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return strongPattern.test(password);
  }
}
