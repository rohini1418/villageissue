import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Auth } from '../../services/auth';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewissues',
  imports: [CommonModule, FormsModule],
  templateUrl: './viewissues.html',
  styleUrls: ['./viewissues.css'],
})
export class Viewissues implements OnInit {

  issues: any[] = [];

  constructor(
    private authservice: Auth,private cd: ChangeDetectorRef,private router: Router
  ) {}

  ngOnInit() {
    this.loadIssues();
  }

  // ✅ Correct updateStatus method
  updateStatus(issueId: any, status: string) {
    const body = { status: status };

    this.authservice.updateIssueStatus(issueId, body).subscribe({
      next: () => {
        alert("Status updated!");
      },
      error: (err) => {
        console.error(err);
        alert("Failed to update status");
      }
    });
  }

  loadIssues() {
    console.log("loading the issues");
    this.authservice.getAllIssues().subscribe(
      (data: any) => {
        console.log(data);
        this.issues = data;
        this.cd.detectChanges();
      },
      (error) => {
        console.error(error);
      }
    );
  }

  notifyUser(issueId: any) {
    this.router.navigate(['notify', issueId]);
  }

}
