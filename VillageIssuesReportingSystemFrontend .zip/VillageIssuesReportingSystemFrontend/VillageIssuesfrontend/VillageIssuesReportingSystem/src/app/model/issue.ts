import { User } from "./user";

export class Issue {
  issueId?: number;
  title!: string;
  description!: string;
  villageName!: string;
  category!: string;
  status!: string;
  photo?: string;
  createdDate?: Date;
  user?: User;
  response!:string;
}
