export class User {
  userId?: number;
  name!: string;
  phone!: string;
  email!: string;
  password!: string;
  role!: string;
}
