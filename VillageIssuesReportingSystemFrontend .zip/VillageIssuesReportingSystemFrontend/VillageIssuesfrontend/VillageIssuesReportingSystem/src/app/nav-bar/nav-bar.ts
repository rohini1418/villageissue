import { Component, Input } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.html',
  styleUrls: ['./nav-bar.css'],
  standalone: true,
  imports: [CommonModule,RouterModule]
})
export class NavBarComponent {

  @Input() userId!: number;

  constructor(private router: Router) {}

  // Go to WelcomeComponent (Home)
  goToHome() {
    this.router.navigate(['/']); // navigate to '' route, your WelcomeComponent
  }

  goToDashboard() {
    this.router.navigate(['/dashboard', this.userId]);
  }

  goToUserPage() {
    this.router.navigate(['/user', this.userId]); // make sure /user/:id route exists
  }

  goToReport() {
    this.router.navigate(['/report-issue', this.userId]);
  }

  logout() {
    this.router.navigate(['/login']);
  }
}
