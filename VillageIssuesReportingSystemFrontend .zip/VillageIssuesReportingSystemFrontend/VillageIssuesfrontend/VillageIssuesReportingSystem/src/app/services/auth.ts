import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Auth {

  private userUrl = 'http://localhost:8084/users';
  private issueBaseUrl = 'http://localhost:8084/issues';

  constructor(private httpClient: HttpClient,private router:Router) {}

  // User login
  loginUser(user: any): Observable<any> {
    return this.httpClient.post(`${this.userUrl}/login`, user);
  }

  // User registration
  registerUsers(user: any): Observable<any> {
    return this.httpClient.post(`${this.userUrl}/register`, user);
  }

  // Report a new issue
  reportIssue(formData: FormData): Observable<any> {
    return this.httpClient.post(`${this.issueBaseUrl}/add`, formData);
  }

  // Get issue by id
  getSingleIssue(id: any): Observable<any> {
    return this.httpClient.get(`${this.issueBaseUrl}/getIssues/${id}`);
  }

  // Update issue response (Admin → Notify user)
  updateIssueResponse(id: any,issue:any): Observable<any> {
    return this.httpClient.put(`${this.issueBaseUrl}/update/${id}`, issue);
  }

 // auth.service.ts
notifyUser(payload: any) {
  return this.httpClient.post('http://localhost:8084/issues/notify', payload, { responseType: 'text' });
}

updateIssueStatus(issueId: number, body: any) {
  return this.httpClient.put(`http://localhost:8084/issues/status/${issueId}`, body);
}
  // Fetch all issues
  getAllIssues(): Observable<any> {
    return this.httpClient.get(`${this.issueBaseUrl}/all`);
  }
   logout() {
    localStorage.removeItem('token'); // or user data
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }
}






